

const WeatherCard = ({ title, value }) => (
    <div className="weather-card">
      <h2>{title}</h2>
      <p>{value}</p>
    </div>
  );

  export default WeatherCard;