import { useState, useEffect } from 'react';
import '../src/App.css';
import axios from 'axios';

const WeatherCard = ({ title, value }) => (
  <div className="weather-card">
    <h2 className='title_card'>{title}</h2>
    <p className="value_card">{value}</p>
  </div>
);

const WeatherApp = () => {    
  const [currentWeather, setCurrentWeather] = useState({});

  const getData = async () => {
    const { data } = await axios.get('https://api.weatherapi.com/v1/current.json?q=13.10823487741827,%2080.09387105494231&key=9e496239986444e3819114029240507')
    setCurrentWeather(data);
  }

  useEffect(() => {
    setInterval(()=>getData(),1000)
  }, [])

  console.log(currentWeather);

  return (
    <>
      <h1 className='main_title'>Weather App</h1>
      <div className="app-container">
        <div className="weather-container">
          <WeatherCard title="Temperature" className="temperature-card" value={currentWeather?.current?.temp_c + "°C"} />
          <WeatherCard title="Precipitation" className="preception-card" value={currentWeather?.current?.precip_mm + "mm"} />
          <WeatherCard title="Wind Speed" className="wind-card" value={currentWeather?.current?.wind_kph + "km/h"} />
          <WeatherCard title="Wind Direction" className="preception-card" value={currentWeather?.current?.wind_dir} />
        </div>
      </div>
    </>
  );
};

export default WeatherApp;
